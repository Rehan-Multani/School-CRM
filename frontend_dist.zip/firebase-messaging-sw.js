importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');
const firebaseConfig = {
  apiKey: "",
  authDomain: "school-crm-99cc8.firebaseapp.com",
  projectId: "school-crm-99cc8",
  storageBucket: "school-crm-99cc8.firebasestorage.app",
  messagingSenderId: "",
  appId: ""
};
if (firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId) {
  firebase.initializeApp(firebaseConfig);
  const messaging = firebase.messaging();
  messaging.onBackgroundMessage((payload) => {
    const title = payload.notification?.title || payload.data?.title || 'School CRM';
    const body = payload.notification?.body || payload.data?.body || '';
    self.registration.showNotification(title, { body, icon: '/School_logo.png' });
  });
}
