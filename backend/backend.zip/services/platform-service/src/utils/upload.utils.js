

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import sharp from 'sharp';
import { AppError } from '../../../shared/AppError.js';

sharp.cache(false);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


export const uploadsRoot = process.env.VERCEL
  ? path.join('/tmp', 'uploads')
  : path.resolve(__dirname, '../../uploads');
export const studentUploadsDir = path.join(uploadsRoot, 'students');
export const studentDocumentsDir = path.join(studentUploadsDir, 'documents');
export const teacherUploadsDir = path.join(uploadsRoot, 'teachers');
export const teacherDocumentsDir = path.join(teacherUploadsDir, 'documents');
export const teacherResourcesDir = path.join(uploadsRoot, 'teacher-resources');
export const userUploadsDir = path.join(uploadsRoot, 'users');
export const userDocumentsDir = path.join(userUploadsDir, 'documents');
export const driverUploadsDir = path.join(uploadsRoot, 'drivers');
export const driverDocumentsDir = path.join(driverUploadsDir, 'documents');

export function ensureUploadDirs() {
  fs.mkdirSync(studentUploadsDir, { recursive: true });
  fs.mkdirSync(studentDocumentsDir, { recursive: true });
  fs.mkdirSync(teacherUploadsDir, { recursive: true });
  fs.mkdirSync(teacherDocumentsDir, { recursive: true });
  fs.mkdirSync(teacherResourcesDir, { recursive: true });
  fs.mkdirSync(userUploadsDir, { recursive: true });
  fs.mkdirSync(userDocumentsDir, { recursive: true });
  fs.mkdirSync(driverUploadsDir, { recursive: true });
  fs.mkdirSync(driverDocumentsDir, { recursive: true });
}

export function toTeacherResourcePublicPath(filename) {
  return `/uploads/teacher-resources/${filename}`;
}

export function toStudentPhotoPublicPath(filename) {
  return `/uploads/students/${filename}`;
}

export function toStudentDocumentPublicPath(filename) {
  return `/uploads/students/documents/${filename}`;
}

export function toTeacherPhotoPublicPath(filename) {
  return `/uploads/teachers/${filename}`;
}

export function toTeacherDocumentPublicPath(filename) {
  return `/uploads/teachers/documents/${filename}`;
}

export function toUserPhotoPublicPath(filename) {
  return `/uploads/users/${filename}`;
}

export function toUserDocumentPublicPath(filename) {
  return `/uploads/users/documents/${filename}`;
}

export function toDriverPhotoPublicPath(filename) {
  return `/uploads/drivers/${filename}`;
}

export function toDriverLicensePublicPath(filename) {
  return `/uploads/drivers/documents/${filename}`;
}

export function resolveUploadPath(publicPath) {
  if (!publicPath || typeof publicPath !== 'string') return null;
  // Stripping the leading slash is not containment: path.join happily resolves
  // `../../..` back out of the uploads root, so any stored path that ever came
  // from user input would become an arbitrary-file read/delete. Resolve first,
  // then require the result to still sit inside uploadsRoot.
  if (publicPath.includes('\0')) return null;
  // Stored paths are `/uploads/<dir>/<file>` — the HTTP mount point. `uploadsRoot`
  // *is* that mount's directory, so the leading `uploads/` segment has to come off
  // or every path resolves to `<root>/uploads/...` and silently misses the file
  // (which is why deleted/replaced photos were never actually unlinked).
  const sanitized = publicPath.replace(/^\/+/, '').replace(/^uploads\//, '');
  const resolved = path.resolve(uploadsRoot, sanitized.replace(/\//g, path.sep));
  const root = path.resolve(uploadsRoot);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) return null;
  return resolved;
}

export function deleteUploadedFile(publicPath) {
  const filePath = resolveUploadPath(publicPath);
  if (!filePath) return;
  if (fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
    } catch {
      // Ignore deletion failure
    }
  }
}

export function listMulterFiles(files) {
  if (!files) return [];
  if (Array.isArray(files)) return files.filter(Boolean);
  if (files.path || files.filename) return [files];
  return Object.values(files)
    .flat()
    .filter(Boolean);
}

export function deleteMulterFiles(files) {
  for (const file of listMulterFiles(files)) {
    if (file?.path && fs.existsSync(file.path)) {
      try {
        fs.unlinkSync(file.path);
      } catch {
        // Ignore deletion failure
      }
    }
  }
}

/**
 * Universal Image-to-WebP Converter
 * Converts any uploaded image (JPEG, PNG, GIF, BMP, TIFF, SVG, etc.) to optimized WebP.
 *
 * @param {Object} file - Multer file object
 * @param {Object} [options] - Sharp optimization options
 * @returns {Promise<Object>} - Updated Multer file object with .webp extension and mime
 */
// P1: fail-fast on obviously non-image / executable payloads before they reach
// sharp. sharp already rejects non-images, but this blocks polyglots and script
// uploads (spoofed Content-Type) earlier and unambiguously.
const DANGEROUS_SIGNATURES = [
  Buffer.from('MZ'), // Windows PE / DOS executable
  Buffer.from('\x7fELF', 'binary'), // Linux ELF
  Buffer.from('#!'), // shell / script shebang
  Buffer.from('PK\x03\x04', 'binary'), // zip / jar / office / apk
  Buffer.from('<?php'),
  Buffer.from('<%'), // asp / jsp
  Buffer.from('\xca\xfe\xba\xbe', 'binary'), // java class / mach-o fat
  Buffer.from('Rar!'),
];

function assertNotDangerousUpload(filePath) {
  let head;
  try {
    const fd = fs.openSync(filePath, 'r');
    head = Buffer.alloc(16);
    fs.readSync(fd, head, 0, 16, 0);
    fs.closeSync(fd);
  } catch {
    return; // let sharp deal with unreadable files
  }
  for (const sig of DANGEROUS_SIGNATURES) {
    if (head.subarray(0, sig.length).equals(sig)) {
      throw new AppError('This file type is not allowed.', 400);
    }
  }
}

export async function convertUploadedImageToWebp(file, options = {}) {
  if (!file?.path) return file;

  assertNotDangerousUpload(file.path);

  const parsed = path.parse(file.path);
  const finalDestPath = path.join(parsed.dir, `${parsed.name}.webp`);

  try {
    // Read input file into memory buffer so libvips/sharp never holds an OS file lock on Windows
    const inputBuffer = fs.readFileSync(file.path);

    const image = sharp(inputBuffer, { failOn: 'none' }).rotate(); // Auto-orient based on EXIF

    // Resize if excessive (e.g. > 2048px width/height) to save storage & bandwidth
    const metadata = await image.metadata();
    if (metadata.width > 2048 || metadata.height > 2048) {
      image.resize({
        width: metadata.width > 2048 ? 2048 : undefined,
        height: metadata.height > 2048 ? 2048 : undefined,
        fit: 'inside',
        withoutEnlargement: true,
      });
    }

    // Convert to WebP buffer with balanced quality and compression
    const webpBuffer = await image
      .webp({
        quality: options.quality || 82,
        effort: 4,
        lossless: false,
      })
      .toBuffer();

    // Remove original uploaded file if different from final destination
    if (file.path !== finalDestPath && fs.existsSync(file.path)) {
      try {
        fs.unlinkSync(file.path);
      } catch {
        // Ignore deletion failure
      }
    }

    // Write final WebP file
    fs.writeFileSync(finalDestPath, webpBuffer);

    // Update Multer file reference
    file.filename = `${parsed.name}.webp`;
    file.path = finalDestPath;
    file.mimetype = 'image/webp';
    return file;
  } catch (error) {
    if (file.path !== finalDestPath && fs.existsSync(file.path)) {
      try { fs.unlinkSync(file.path); } catch {}
    }
    if (fs.existsSync(finalDestPath)) {
      try { fs.unlinkSync(finalDestPath); } catch {}
    }
    throw new AppError(`Failed to process and convert image to WebP: ${error.message}`, 400);
  }
}

/**
 * Universal Express Middleware to automatically convert ALL uploaded images
 * in req.file or req.files to WebP format.
 */
export async function convertAllUploadedImagesToWebp(req, res, next) {
  try {
    const files = [];
    if (req.file) files.push(req.file);
    if (req.files) files.push(...listMulterFiles(req.files));

    for (const file of files) {
      if (file?.mimetype?.startsWith('image/') || /\.(jpg|jpeg|png|gif|bmp|webp|tiff|svg)$/i.test(file?.originalname || '')) {
        await convertUploadedImageToWebp(file);
      }
    }
    next();
  } catch (error) {
    if (req.file) deleteMulterFiles(req.file);
    if (req.files) deleteMulterFiles(req.files);
    next(error);
  }
}
