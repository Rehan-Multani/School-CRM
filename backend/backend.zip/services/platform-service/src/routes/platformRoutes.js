import { Router } from 'express';
import {
  loginRateLimiter,
  passwordResetRateLimiter,
  appPasswordResetRateLimiter,
  otpLoginRateLimiter,
} from '../middleware/loginRateLimiter.js';
import { requestLoginOtp, verifyLoginOtp, selectLoginOtpAccount } from '../controllers/otpLogin.controller.js';
import {
  requestPasswordResetOtp,
  verifyPasswordResetOtp,
  resetPasswordWithOtpToken,
} from '../controllers/passwordReset.controller.js';
import { requirePlatformUser } from '../middleware/requirePlatformUser.js';
import { validateObjectId } from '../middleware/validateObjectId.js';
import teacherApkRoutes from './teacher.routes.js';
import studentApkRoutes from './student.routes.js';
import parentApkRoutes from './parent.routes.js';
import driverRoutes from './driver.routes.js';
import {
  notifyAppUpdate,
  getLogoutNotice,
  superForceLogout,
  superForceLogoutHistory,
} from '../controllers/appSession.controller.js';
import transportManagerRoutes from './transportManager.routes.js';
import { getTransportOverview, getTransportRouteRun } from '../controllers/transportManager.controller.js';
import {
  getSafePickupSettings,
  updateSafePickupClass,
  getSafePickupHistory,
} from '../controllers/safePickupSettings.controller.js';
import {
  listSafePickupStudents,
  sendSafePickupOtp,
  verifySafePickupOtp,
  getSafePickupHistory as getAdminSafePickupHistory,
} from '../controllers/adminSafePickup.controller.js';
import {
  getServiceInfo,
  healthCheck,
  notFound,
} from '../controllers/platform.controller.js';
import {
  getLegalDocuments,
  updateLegalDocuments,
} from '../controllers/legal.controller.js';
import {
  getPlatformSettings,
  updatePlatformSettings,
  updatePlatformLogo,
  deletePlatformLogo,
} from '../controllers/platformSetting.controller.js';
import { uploadPlatformLogo } from '../middleware/uploadPlatformLogo.js';
import {
  createSchoolTicket,
  createTicket,
  getSchoolTicket,
  getTicket,
  listSchoolTickets,
  listTickets,
  replySchoolTicket,
  replyTicket,
  updateTicketStatus,
} from '../controllers/support.controller.js';
import {
  createSchool,
  deleteSchool,
  listSchools,
  resetSchoolLogin,
  changeSchoolAdminPassword,
  schoolAdminForgotPassword,
  schoolAdminLogin,
  schoolAdminResetPassword,
  schoolBranding,
  getSchoolFeatures,
  updateSchoolFeatures,
  schoolThemePublic,
  schoolPortalChangePassword,
  schoolPortalConfig,
  schoolPortalMe,
  schoolPortalPlans,
  schoolPortalSettings,
  schoolPortalUpdateBranding,
  schoolPortalUpdateConfig,
  schoolPortalUpdateEmail,
  schoolPortalUpdateTheme,
  schoolInitiateSubscriptionCheckout,
  updateSchool,
  updateSchoolStatus,
} from '../controllers/school.controller.js';
import {
  createPlan,
  deletePlan,
  listPlans,
  updatePlan,
  getPlan,
  archivePlan,
} from '../controllers/subscription.controller.js';
import {
  createSchoolSubscription,
  listSchoolSubscriptions,
  getSubscriptionStats,
  getSchoolSubscriptionById,
  cancelSchoolSubscription,
  changeSchoolSubscriptionPlan,
  overrideSchoolSubscription,
  listSubscriptionPayments,
  listSubscriptionInvoices,
  listSubscriptionHistory,
  getMySubscription,
  getMyEntitlement,
  checkoutMySubscription,
  changeMySubscriptionPlan,
  cancelMySubscription,
  listMySubscriptionPayments,
  listMySubscriptionInvoices,
  listMySubscriptionHistory,
  getSubscriptionCheckoutInfo,
} from '../controllers/schoolSubscription.controller.js';
import {
  inboxNotifications,
  listNotifications,
  listSchoolNotifications,
  registerDevice,
  sendNotification,
  sendSchoolNotification,
  sendLibraryNotification,
} from '../controllers/notification.controller.js';
import {
  cancelInvoice,
  createInvoice,
  createRazorpayOrder,
  getInvoice,
  getPaymentGateway,
  listInvoices,
  markInvoicePaid,
  refundInvoice,
  verifyRazorpayPayment,
} from '../controllers/billing.controller.js';
import {
  getReportSummary,
  listInvoiceReports,
  listNotificationReports,
  listSchoolReports,
  listSubscriptionReports,
} from '../controllers/report.controller.js';
import {
  activateAcademicYear,
  addClassToYear,
  addSectionSubject,
  archiveAcademicYear,
  unarchiveAcademicYear,
  completeAcademicYear,
  createAcademicYear,
  createClass,
  createSection,
  createSubject,
  createTeacher,
  deleteAcademicYear,
  deleteClass,
  deleteSection,
  deleteSectionSubject,
  deleteSubject,
  getAcademicYear,
  getClass,
  getSection,
  getTeacher,
  listAcademicYears,
  listClasses,
  listAllSectionSubjects,
  listSectionSubjects,
  createSectionSubjectDirect,
  listSections,
  listSubjects,
  listTeachers,
  listYearClasses,
  removeClassFromYear,
  seedClasses,
  setCurrentAcademicYear,
  updateAcademicYear,
  updateClass,
  updateSection,
  updateSectionSubject,
  updateSubject,
  updateTeacher,
  updateTeacherStatus,
  deleteTeacher,
  setTeacherPassword,
  setStudentPassword,
  createParent,
  setParentPassword,
  linkParentChild,
  unlinkParentChild,
} from '../controllers/academic.controller.js';
import {
  createStudent,
  deleteStudent,
  getStudent,
  listStudents,
  updateStudent,
  updateStudentStatus,
} from '../controllers/student.controller.js';
import {
  listFeeHeads,
  getFeeHead,
  createFeeHead,
  updateFeeHead,
  deleteFeeHead,
  seedDefaultFeeHeads,
  bulkCreateFeeHeads,
  listFeeStructures,
  getFeeStructure,
  createFeeStructure,
  updateFeeStructure,
  deleteFeeStructure,
  listStructureItems,
  addStructureItem,
  updateStructureItem,
  deleteStructureItem,
  listStudentAssignments,
  autoAssignStudentFees,
  updateStudentAssignment,
  listStudentFeeAssignments,
  createStudentFeeAssignment,
  listFeeInvoices,
  getFeeInvoice,
  generateFeeInvoice,
  payFeeInvoice,
  listFeePayments,
  getFeePayment,
  collectFeePayment,
  listFinanceTransactions,
  getFinanceSummary,
  recordExpense,
} from '../controllers/fee.controller.js';
import {
  changeUserPassword,
  createUser,
  deleteUser,
  getUser,
  listUsers,
  seedUsers,
  sendUserCredentials,
  updateUser,
  updateUserStatus,
} from '../controllers/user.controller.js';
import {
  createPayroll,
  deletePayroll,
  getEligibleEmployees,
  getPayroll,
  listPayrolls,
  releaseAllPayrolls,
  updatePayrollStatus,
} from '../controllers/payroll.controller.js';
import {
  getAttendanceReport,
  getDailyAttendance,
  getMonthlySummary,
  markAllStatus,
  saveDailyAttendance,
  updateSingleStatus,
} from '../controllers/staffAttendance.controller.js';
import {
  librarianLogin,
  getLibrarianProfile,
  updateLibrarianProfile,
  getLibrarySettings,
  updateLibrarySettings,
  getLibraryStats,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getAuthors,
  getPublishers,
  listBooks,
  getBook,
  createBook,
  updateBook,
  deleteBook,
  listBookCopies,
  createBookCopy,
  updateBookCopy,
  deleteBookCopy,
  listIssues,
  issueBook,
  returnBook,
  renewBook,
  updateFineStatus,
  getEligibleBorrowers,
  getNotificationRecipients,
  listReservations,
  createReservation,
  approveReservation,
  rejectReservation,
  cancelReservation,
  fulfillReservation,
  listTransactions,
  getReportData,
} from '../controllers/library.controller.js';
import {
  addExamSubject,
  calculateResults,
  createExam,
  createScheduleEntry,
  deleteExam,
  deleteExamSubject,
  deleteScheduleEntry,
  getExam,
  getExamStats,
  getStudentReportCard,
  listExams,
  listExamSubjects,
  listMarksSheet,
  listResults,
  listSchedule,
  saveMarks,
  seedExamSubjects,
  updateExam,
  updateExamSubject,
  updateScheduleEntry,
} from '../controllers/exam.controller.js';
import {
  listHostels,
  getHostel,
  createHostel,
  updateHostel,
  deleteHostel,
  listRooms,
  getRoom,
  createRoom,
  updateRoom,
  deleteRoom,
  listBeds,
  listWardens,
  getWarden,
  createWarden,
  updateWarden,
  assignWardenToHostel,
  unassignWardenFromHostel,
  deleteWarden,
  listAllocations,
  allocateStudent,
  updateAllocation,
  vacateAllocation,
  listHostelFees,
  setHostelFee,
  deleteHostelFee,
  getHostelLookups,
} from '../controllers/hostel.controller.js';
import {
  listVehicles,
  getVehicle,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  listDrivers,
  getDriver,
  createDriver,
  updateDriver,
  assignVehicleToDriver,
  unassignVehicleFromDriver,
  deleteDriver,
  listRoutes,
  getRoute,
  createRoute,
  updateRoute,
  assignRouteResources,
  unassignRouteResources,
  deleteRoute,
  listStops,
  createStop,
  updateStop,
  deleteStop,
  reorderStops,
  listAssignments,
  assignStudent,
  updateAssignment,
  removeAssignment,
  getTransportLookups,
  listTransportFees,
  setTransportFee,
  deleteTransportFee,
} from '../controllers/transport.controller.js';
import { getSchoolAdminDashboardSummary } from '../controllers/schoolDashboard.controller.js';
import { getSchoolReportsSummary, getCategoryReportData } from '../controllers/schoolReports.controller.js';
import {
  listEvents,
  getEventStats,
  getEvent,
  createEvent,
  updateEvent,
  deleteEvent,
} from '../controllers/event.controller.js';
import {
  listHomework,
  getHomeworkStats,
  getHomeworkMonitor,
  getHomework,
  createHomework,
  updateHomework,
  deleteHomework,
} from '../controllers/homework.controller.js';
import {
  listMeetings,
  getMeeting,
  createMeeting,
  updateMeeting,
  updateMeetingStatus,
  deleteMeeting,
} from '../controllers/meeting.controller.js';
import {
  listAdmissions,
  getAdmissionStats,
  getAdmission,
  createAdmission,
  updateAdmission,
  updateAdmissionStatus,
  approveAdmission,
  deleteAdmission,
} from '../controllers/admission.controller.js';
import {
  listAssetCategories,
  createAssetCategory,
  updateAssetCategory,
  deleteAssetCategory,
  getInventoryStats,
  listStockMovements,
  listAssets,
  getAsset,
  createAsset,
  updateAsset,
  deleteAsset,
  recordAssetMovement,
} from '../controllers/inventory.controller.js';
import { listAuditLogs } from '../controllers/auditLog.controller.js';
import {
  getPermissionCatalogue,
  listRoles,
  getRole,
  createRole,
  updateRole,
  deleteRole,
  assignUserRole,
} from '../controllers/role.controller.js';
import {
  getStudentAttendanceDay,
  saveStudentAttendanceDay,
  markSingleStudentAttendance,
  markAllStudentAttendance,
  getStudentAttendanceMonitor,
  getStudentAttendanceReport,
} from '../controllers/studentAttendance.controller.js';
import {
  listAnnouncements as commListAnnouncements,
  createAnnouncement as commCreateAnnouncement,
  updateAnnouncement as commUpdateAnnouncement,
  publishAnnouncement as commPublishAnnouncement,
  deleteAnnouncement as commDeleteAnnouncement,
  listBroadcasts as commListBroadcasts,
  createBroadcast as commCreateBroadcast,
  listThreads as commListThreads,
  getThread as commGetThread,
  replyThread as commReplyThread,
  inboundMessage as commInboundMessage,
} from '../controllers/communication.controller.js';
import { requireSuperAdmin } from '../middleware/requireSuperAdmin.js';
import { requireSchoolAdmin } from '../middleware/requireSchoolAdmin.js';
import { requireLibrarian } from '../middleware/requireLibrarian.js';
import { requireHR } from '../middleware/requireHR.js';
import { requirePrincipal } from '../middleware/requirePrincipal.js';
import { requireSchoolAdminOrPrincipal } from '../middleware/requireSchoolAdminOrPrincipal.js';
import { requireAccountant } from '../middleware/requireAccountant.js';
import { requirePermission } from '../middleware/requirePermission.js';
import {
  principalLogin,
  getPrincipalProfile,
  updatePrincipalProfile,
  changePrincipalPassword,
} from '../controllers/principal.controller.js';
import {
  accountantLogin,
  getAccountantProfile,
  updateAccountantProfile,
  changeAccountantPassword,
  getAccountantDashboard,
  listAccountantAcademicYears,
  listAccountantClasses,
  listAccountantSections,
  searchAccountantStudents,
  getAccountantStudent,
  getStudentFeeProfile,
  accountantGenerateInvoice,
  accountantCollectPayment,
  listAccountantFeeStructures,
  getAccountantFeeStructure,
  listAccountantInstallments,
  listAccountantDues,
  getAccountantStudentDueHistory,
  listAccountantExpenses,
  getAccountantExpense,
  createAccountantExpense,
  updateAccountantExpense,
  updateAccountantExpenseStatus,
  deleteAccountantExpense,
  listAccountantExpenseCategories,
  listAccountantReceipts,
  getAccountantReceipt,
  listAccountantInvoices,
  getAccountantInvoice,
  listAccountantTransactions,
  getAccountantTransaction,
  listAccountantNotifications,
  getAccountantReport,
  getAccountantSettings,
  updateAccountantSettings,
} from '../controllers/accountant.controller.js';
import {
  hrLogin,
  getHRDashboard,
  listEmployees as hrListEmployees,
  getEmployee as hrGetEmployee,
  createEmployee as hrCreateEmployee,
  updateEmployee as hrUpdateEmployee,
  updateEmployeeStatus as hrUpdateEmployeeStatus,
  approveEmployee as hrApproveEmployee,
  rejectEmployee as hrRejectEmployee,
  deleteEmployee as hrDeleteEmployee,
  listDepartments as hrListDepartments,
  createDepartment as hrCreateDepartment,
  updateDepartment as hrUpdateDepartment,
  deleteDepartment as hrDeleteDepartment,
  listDesignations as hrListDesignations,
  createDesignation as hrCreateDesignation,
  updateDesignation as hrUpdateDesignation,
  deleteDesignation as hrDeleteDesignation,
  getHRAttendance,
  saveHRAttendance,
  updateSingleAttendance,
  markAllHRAttendance,
  getHRMonthlyAttendance,
  getHRAttendanceReport,
  listLeaveRequests,
  createLeaveRequest,
  approveLeave,
  rejectLeave,
  cancelLeave,
  getLeaveBalance,
  listHRPayrolls,
  getHREligiblePayrollEmployees,
  createHRPayroll,
  getHRPayroll,
  updateHRPayrollStatus,
  releaseAllHRPayrolls,
  deleteHRPayroll,
  listPerformanceReviews,
  createPerformanceReview,
  getPerformanceReview,
  updatePerformanceReview,
  deletePerformanceReview,
  listHRDocuments,
  uploadHRDocument,
  verifyHRDocument,
  deleteHRDocument,
  getHRSettings,
  updateHRSettings,
  getHRReportData,
  listAnnouncements as hrListAnnouncements,
  createAnnouncement as hrCreateAnnouncement,
  updateAnnouncement as hrUpdateAnnouncement,
  deleteAnnouncement as hrDeleteAnnouncement,
  getHRProfile,
  updateHRProfile,
  changeHRPassword,
  getHRNotifications,
  getHRSalarySlip,
} from '../controllers/hr.controller.js';
import {
  listTimetable,
  createTimetable,
  updateTimetable,
  deleteTimetable,
} from '../controllers/timetable.controller.js';
import { assertSchoolAccess } from '../middleware/assertSchoolAccess.js';
import { uploadStudentFiles, convertStudentImages } from '../middleware/uploadStudentPhoto.js';
import { convertTeacherImages, uploadTeacherFiles } from '../middleware/uploadTeacherPhoto.js';
import { convertSchoolUserImages, uploadSchoolUserFiles } from '../middleware/uploadSchoolUser.js';
import { uploadDriverFiles, convertDriverImages } from '../middleware/uploadDriverFiles.js';

const router = Router();

router.get('/health', healthCheck);
router.get('/schools', requireSuperAdmin, listSchools);
router.post('/schools', requireSuperAdmin, createSchool);
router.put('/schools/:id', requireSuperAdmin, updateSchool);
router.get('/schools/:id/features', requireSuperAdmin, validateObjectId('id'), getSchoolFeatures);
router.patch('/schools/:id/features', requireSuperAdmin, validateObjectId('id'), updateSchoolFeatures);
router.patch('/schools/:id/status', requireSuperAdmin, updateSchoolStatus);
router.post('/schools/:id/reset-login', requireSuperAdmin, resetSchoolLogin);
router.post('/schools/:id/change-password', requireSuperAdmin, validateObjectId('id'), changeSchoolAdminPassword);
router.delete('/schools/:id', requireSuperAdmin, deleteSchool);
router.get('/school-auth/branding', schoolBranding);
router.get('/school-theme/:schoolId', schoolThemePublic);
router.post('/school-auth/login', loginRateLimiter, schoolAdminLogin);
router.post('/school-auth/librarian-login', loginRateLimiter, librarianLogin);
router.post('/school-portal/auth/librarian-login', loginRateLimiter, librarianLogin);
router.post('/school-auth/hr-login', loginRateLimiter, hrLogin);
router.post('/school-portal/auth/hr-login', loginRateLimiter, hrLogin);
router.post('/school-auth/principal-login', loginRateLimiter, principalLogin);
router.post('/school-portal/auth/principal-login', loginRateLimiter, principalLogin);
router.get('/school-portal/principal/me', requirePrincipal, getPrincipalProfile);
router.patch('/school-portal/principal/profile', requirePrincipal, uploadSchoolUserFiles, convertSchoolUserImages, updatePrincipalProfile);
router.patch('/school-portal/principal/password', requirePrincipal, changePrincipalPassword);
router.post('/school-auth/accountant-login', loginRateLimiter, accountantLogin);
router.post('/school-portal/auth/accountant-login', loginRateLimiter, accountantLogin);
router.get('/school-portal/accountant/profile', requireAccountant, getAccountantProfile);
router.patch('/school-portal/accountant/profile', requireAccountant, uploadSchoolUserFiles, convertSchoolUserImages, updateAccountantProfile);
router.patch('/school-portal/accountant/password', requireAccountant, changeAccountantPassword);

// ----- Accountant Portal (all behind requireAccountant) -----
router.get('/school-portal/accountant/dashboard', requireAccountant, getAccountantDashboard);

router.get('/school-portal/accountant/academic-years', requireAccountant, listAccountantAcademicYears);
router.get('/school-portal/accountant/classes', requireAccountant, listAccountantClasses);
router.get('/school-portal/accountant/sections', requireAccountant, listAccountantSections);
router.get('/school-portal/accountant/students', requireAccountant, searchAccountantStudents);
router.get('/school-portal/accountant/students/:id', requireAccountant, getAccountantStudent);

router.get('/school-portal/accountant/fees/students/:studentId/profile', requireAccountant, getStudentFeeProfile);
router.post('/school-portal/accountant/fees/invoices/generate', requireAccountant, accountantGenerateInvoice);
router.post('/school-portal/accountant/fees/invoices/:invoiceId/pay', requireAccountant, accountantCollectPayment);

router.get('/school-portal/accountant/fee-structures', requireAccountant, listAccountantFeeStructures);
router.get('/school-portal/accountant/fee-structures/:id', requireAccountant, getAccountantFeeStructure);

router.get('/school-portal/accountant/installments', requireAccountant, listAccountantInstallments);

router.get('/school-portal/accountant/dues', requireAccountant, listAccountantDues);
router.get('/school-portal/accountant/dues/:studentId/history', requireAccountant, getAccountantStudentDueHistory);

router.get('/school-portal/accountant/expenses/categories', requireAccountant, listAccountantExpenseCategories);
router.get('/school-portal/accountant/expenses', requireAccountant, listAccountantExpenses);
router.post('/school-portal/accountant/expenses', requireAccountant, uploadSchoolUserFiles, convertSchoolUserImages, createAccountantExpense);
router.get('/school-portal/accountant/expenses/:id', requireAccountant, getAccountantExpense);
router.patch('/school-portal/accountant/expenses/:id', requireAccountant, uploadSchoolUserFiles, convertSchoolUserImages, updateAccountantExpense);
router.patch('/school-portal/accountant/expenses/:id/status', requireAccountant, updateAccountantExpenseStatus);
router.delete('/school-portal/accountant/expenses/:id', requireAccountant, deleteAccountantExpense);

router.get('/school-portal/accountant/receipts', requireAccountant, listAccountantReceipts);
router.get('/school-portal/accountant/receipts/:id', requireAccountant, getAccountantReceipt);
router.get('/school-portal/accountant/invoices', requireAccountant, listAccountantInvoices);
router.get('/school-portal/accountant/invoices/:id', requireAccountant, getAccountantInvoice);

router.get('/school-portal/accountant/transactions', requireAccountant, listAccountantTransactions);
router.get('/school-portal/accountant/transactions/:id', requireAccountant, getAccountantTransaction);

router.get('/school-portal/accountant/notifications', requireAccountant, listAccountantNotifications);

router.get('/school-portal/accountant/reports/:category', requireAccountant, getAccountantReport);

router.get('/school-portal/accountant/settings', requireAccountant, getAccountantSettings);
router.patch('/school-portal/accountant/settings', requireAccountant, updateAccountantSettings);
router.post('/school-auth/forgot-password', passwordResetRateLimiter, schoolAdminForgotPassword);
router.post('/school-auth/reset-password', passwordResetRateLimiter, schoolAdminResetPassword);
// Mobile-app roles (teacher / student / parent / transport manager / driver): forgot password by SMS OTP.
router.post('/school-portal/auth/forgot-password', appPasswordResetRateLimiter, requestPasswordResetOtp);
router.post('/school-portal/auth/verify-reset-otp', appPasswordResetRateLimiter, verifyPasswordResetOtp);
router.post('/school-portal/auth/reset-password', appPasswordResetRateLimiter, resetPasswordWithOtpToken);
// Student / parent apps: sign in with the mobile number given at admission + SMS OTP.
router.post('/school-portal/auth/otp-login/request', otpLoginRateLimiter, requestLoginOtp);
router.post('/school-portal/auth/otp-login/verify', otpLoginRateLimiter, verifyLoginOtp);
router.post('/school-portal/auth/otp-login/select', otpLoginRateLimiter, selectLoginOtpAccount);
router.get('/school-portal/dashboard/summary', requirePrincipal, getSchoolAdminDashboardSummary);
router.get('/school-portal/reports/summary', requirePrincipal, getSchoolReportsSummary);
router.get('/school-portal/reports/data', requirePrincipal, getCategoryReportData);
router.get('/school-portal/me', requireSchoolAdmin, schoolPortalMe);
router.get('/school-portal/plans', requireSchoolAdmin, schoolPortalPlans);
router.post('/school-portal/select-plan/checkout', requireSchoolAdmin, schoolInitiateSubscriptionCheckout);
router.get('/school-portal/config', requireSchoolAdmin, schoolPortalConfig);
router.patch('/school-portal/config', requireSchoolAdmin, schoolPortalUpdateConfig);
router.get('/school-portal/settings', requireSchoolAdmin, schoolPortalSettings);
router.patch('/school-portal/settings/theme', requireSchoolAdmin, schoolPortalUpdateTheme);
router.patch('/school-portal/settings/branding', requireSchoolAdmin, schoolPortalUpdateBranding);
router.patch('/school-portal/settings/password', requireSchoolAdmin, schoolPortalChangePassword);
router.patch('/school-portal/settings/email', requireSchoolAdmin, schoolPortalUpdateEmail);

// ---- Student Safe Pickup — School Admin configuration + history ----
// The school-level master switch is Super Admin–only (PATCH /platform/schools/:id/features).
// School admins can read it here for display and manage per-class toggles below.
router.get('/school-portal/settings/safe-pickup', requireSchoolAdmin, requirePermission('pickup.settings'), getSafePickupSettings);
router.patch('/school-portal/academic/classes/:classId/pickup', requireSchoolAdmin, requirePermission('pickup.settings'), validateObjectId('classId'), updateSafePickupClass);
router.get('/school-portal/pickups/history', requireSchoolAdmin, requirePermission('pickup.history'), getSafePickupHistory);

// ---- Safe Pickup (Admin & Principal) — For marking students as safely picked up ----
const requireAdminOrPrincipal = (req, res, next) => {
  const role = req.user?.role;
  if (role !== 'SchoolAdmin' && role !== 'Principal') {
    return res.status(403).json({ success: false, message: 'Unauthorized' });
  }
  next();
};

router.get('/school-portal/safe-pickup/students', requireSchoolAdmin, requireAdminOrPrincipal, listSafePickupStudents);
router.get('/school-portal/principal/safe-pickup/students', requirePrincipal, requireAdminOrPrincipal, listSafePickupStudents);
router.post('/school-portal/safe-pickup/send-otp', requireSchoolAdmin, requireAdminOrPrincipal, sendSafePickupOtp);
router.post('/school-portal/principal/safe-pickup/send-otp', requirePrincipal, requireAdminOrPrincipal, sendSafePickupOtp);
router.post('/school-portal/safe-pickup/verify-otp', requireSchoolAdmin, requireAdminOrPrincipal, verifySafePickupOtp);
router.post('/school-portal/principal/safe-pickup/verify-otp', requirePrincipal, requireAdminOrPrincipal, verifySafePickupOtp);
router.get('/school-portal/safe-pickup/history', requireSchoolAdmin, requireAdminOrPrincipal, getAdminSafePickupHistory);
router.get('/school-portal/principal/safe-pickup/history', requirePrincipal, requireAdminOrPrincipal, getAdminSafePickupHistory);
router.get('/school-portal/principal/safe-pickup/settings', requirePrincipal, requireAdminOrPrincipal, getSafePickupSettings);
router.get('/school-portal/notifications', requirePrincipal, listSchoolNotifications);
router.post('/school-portal/notifications', requirePrincipal, sendSchoolNotification);
router.get('/school-portal/academic/years', requireSchoolAdminOrPrincipal, listAcademicYears);
router.post('/school-portal/academic/years', requireSchoolAdminOrPrincipal, createAcademicYear);
router.get('/school-portal/academic/years/:id', requireSchoolAdminOrPrincipal, getAcademicYear);
router.patch('/school-portal/academic/years/:id', requireSchoolAdminOrPrincipal, updateAcademicYear);
router.delete('/school-portal/academic/years/:id', requireSchoolAdminOrPrincipal, deleteAcademicYear);
router.post('/school-portal/academic/years/:id/activate', requireSchoolAdminOrPrincipal, activateAcademicYear);
router.post('/school-portal/academic/years/:id/set-current', requireSchoolAdminOrPrincipal, setCurrentAcademicYear);
router.post('/school-portal/academic/years/:id/archive', requireSchoolAdminOrPrincipal, archiveAcademicYear);
router.post('/school-portal/academic/years/:id/unarchive', requireSchoolAdminOrPrincipal, unarchiveAcademicYear);
router.post('/school-portal/academic/years/:id/complete', requireSchoolAdminOrPrincipal, completeAcademicYear);
router.get('/school-portal/academic/years/:yearId/classes', requireSchoolAdminOrPrincipal, listYearClasses);
router.post('/school-portal/academic/years/:yearId/classes', requireSchoolAdminOrPrincipal, addClassToYear);
router.delete('/school-portal/academic/years/:yearId/classes/:classId', requireSchoolAdminOrPrincipal, removeClassFromYear);
router.get('/school-portal/academic/classes', requireSchoolAdminOrPrincipal, listClasses);
router.post('/school-portal/academic/classes', requireSchoolAdminOrPrincipal, createClass);
router.post('/school-portal/academic/classes/seed', requireSchoolAdminOrPrincipal, seedClasses);
router.get('/school-portal/academic/classes/:id', requireSchoolAdminOrPrincipal, getClass);
router.patch('/school-portal/academic/classes/:id', requireSchoolAdminOrPrincipal, updateClass);
router.delete('/school-portal/academic/classes/:id', requireSchoolAdminOrPrincipal, deleteClass);
router.get('/school-portal/academic/sections', requireSchoolAdminOrPrincipal, listSections);
router.post('/school-portal/academic/sections', requireSchoolAdminOrPrincipal, createSection);
router.get('/school-portal/academic/sections/:id', requireSchoolAdminOrPrincipal, getSection);
router.patch('/school-portal/academic/sections/:id', requireSchoolAdminOrPrincipal, updateSection);
router.delete('/school-portal/academic/sections/:id', requireSchoolAdminOrPrincipal, deleteSection);
router.get('/school-portal/academic/subjects', requireSchoolAdminOrPrincipal, listSubjects);
router.post('/school-portal/academic/subjects', requireSchoolAdminOrPrincipal, createSubject);
router.patch('/school-portal/academic/subjects/:id', requireSchoolAdminOrPrincipal, updateSubject);
router.delete('/school-portal/academic/subjects/:id', requireSchoolAdminOrPrincipal, deleteSubject);
router.get('/school-portal/academic/section-subjects', requireSchoolAdminOrPrincipal, listAllSectionSubjects);
router.post('/school-portal/academic/section-subjects', requireSchoolAdminOrPrincipal, createSectionSubjectDirect);
router.get('/school-portal/academic/sections/:sectionId/subjects', requireSchoolAdminOrPrincipal, listSectionSubjects);
router.post('/school-portal/academic/sections/:sectionId/subjects', requireSchoolAdminOrPrincipal, addSectionSubject);
router.patch('/school-portal/academic/section-subjects/:id', requireSchoolAdminOrPrincipal, updateSectionSubject);
router.delete('/school-portal/academic/section-subjects/:id', requireSchoolAdminOrPrincipal, deleteSectionSubject);
router.get('/school-portal/academic/teachers', requireSchoolAdminOrPrincipal, listTeachers);
router.post('/school-portal/academic/teachers', requireSchoolAdminOrPrincipal, uploadTeacherFiles, convertTeacherImages, createTeacher);
router.get('/school-portal/academic/teachers/:id', requireSchoolAdminOrPrincipal, getTeacher);
router.patch('/school-portal/academic/teachers/:id', requireSchoolAdminOrPrincipal, uploadTeacherFiles, convertTeacherImages, updateTeacher);
router.patch('/school-portal/academic/teachers/:id/status', requireSchoolAdminOrPrincipal, updateTeacherStatus);
router.post('/school-portal/academic/teachers/:id/set-password', requirePrincipal, validateObjectId('id'), setTeacherPassword);
router.delete('/school-portal/academic/teachers/:id', requireSchoolAdminOrPrincipal, deleteTeacher);

// Class timetable (admin-side CRUD; teachers read it via /school-portal/teacher/timetable)
router.get('/school-portal/timetable', requirePrincipal, listTimetable);
router.post('/school-portal/timetable', requirePrincipal, createTimetable);
router.patch('/school-portal/timetable/:id', requirePrincipal, validateObjectId('id'), updateTimetable);
router.delete('/school-portal/timetable/:id', requirePrincipal, validateObjectId('id'), deleteTimetable);
router.get('/school-portal/students', requirePrincipal, listStudents);
router.post('/school-portal/students', requirePrincipal, uploadStudentFiles, convertStudentImages, createStudent);
router.get('/school-portal/students/:id', requirePrincipal, getStudent);
router.patch('/school-portal/students/:id', requirePrincipal, uploadStudentFiles, convertStudentImages, updateStudent);
router.patch('/school-portal/students/:id/status', requirePrincipal, updateStudentStatus);
router.post('/school-portal/academic/students/:id/set-password', requirePrincipal, validateObjectId('id'), setStudentPassword);
router.delete('/school-portal/students/:id', requirePrincipal, deleteStudent);

// Parent APK account management (principal)
router.post('/school-portal/parents', requirePrincipal, createParent);
router.post('/school-portal/parents/:id/children', requirePrincipal, validateObjectId('id'), linkParentChild);
router.delete('/school-portal/parents/:id/children/:studentId', requirePrincipal, validateObjectId('id'), validateObjectId('studentId'), unlinkParentChild);
router.post('/school-portal/academic/parents/:id/set-password', requirePrincipal, validateObjectId('id'), setParentPassword);

// School User Management Routes (Teachers, Librarians, HR, Accountants, Transport)
router.get('/school-portal/users', requirePrincipal, listUsers);
router.post('/school-portal/users', requirePrincipal, uploadSchoolUserFiles, convertSchoolUserImages, createUser);
router.post('/school-portal/users/seed', requirePrincipal, seedUsers);
router.get('/school-portal/users/:id', requirePrincipal, getUser);
router.patch('/school-portal/users/:id', requirePrincipal, uploadSchoolUserFiles, convertSchoolUserImages, updateUser);
router.patch('/school-portal/users/:id/status', requirePrincipal, updateUserStatus);
router.patch('/school-portal/users/:id/password', requirePrincipal, changeUserPassword);
router.post('/school-portal/users/:id/send-credentials', requirePrincipal, sendUserCredentials);
router.delete('/school-portal/users/:id', requirePrincipal, deleteUser);

// Fee Management Routes
// Fee Heads
router.get('/school-portal/fees/heads', requireSchoolAdmin, listFeeHeads);
router.post('/school-portal/fees/heads', requireSchoolAdmin, createFeeHead);
router.post('/school-portal/fees/heads/seed', requireSchoolAdmin, seedDefaultFeeHeads);
router.post('/school-portal/fees/heads/bulk', requireSchoolAdmin, bulkCreateFeeHeads);
router.get('/school-portal/fees/heads/:id', requireSchoolAdmin, validateObjectId('id'), getFeeHead);
router.patch('/school-portal/fees/heads/:id', requireSchoolAdmin, validateObjectId('id'), updateFeeHead);
router.delete('/school-portal/fees/heads/:id', requireSchoolAdmin, validateObjectId('id'), deleteFeeHead);

// Fee Structures
router.get('/school-portal/fees/structures', requireSchoolAdmin, listFeeStructures);
router.post('/school-portal/fees/structures', requireSchoolAdmin, createFeeStructure);
router.get('/school-portal/fees/structures/:id', requireSchoolAdmin, validateObjectId('id'), getFeeStructure);
router.patch('/school-portal/fees/structures/:id', requireSchoolAdmin, validateObjectId('id'), updateFeeStructure);
router.delete('/school-portal/fees/structures/:id', requireSchoolAdmin, validateObjectId('id'), deleteFeeStructure);

// Fee Structure Items
router.get('/school-portal/fees/structures/:structureId/items', requireSchoolAdmin, validateObjectId('structureId'), listStructureItems);
router.post('/school-portal/fees/structures/:structureId/items', requireSchoolAdmin, validateObjectId('structureId'), addStructureItem);
router.patch('/school-portal/fees/items/:id', requireSchoolAdmin, validateObjectId('id'), updateStructureItem);
router.delete('/school-portal/fees/items/:id', requireSchoolAdmin, validateObjectId('id'), deleteStructureItem);

// Student Fee Assignments
router.get('/school-portal/fees/students/:studentId/assignments', requireSchoolAdmin, validateObjectId('studentId'), listStudentAssignments);
router.post('/school-portal/fees/students/:studentId/auto-assign', requireSchoolAdmin, validateObjectId('studentId'), autoAssignStudentFees);
router.patch('/school-portal/fees/assignments/:id', requireSchoolAdmin, validateObjectId('id'), updateStudentAssignment);
router.get('/school-portal/fees/assignments', requireSchoolAdmin, listStudentFeeAssignments);
router.post('/school-portal/fees/assignments', requireSchoolAdmin, createStudentFeeAssignment);

// Invoices & Payments
router.get('/school-portal/fees/invoices', requireSchoolAdmin, listFeeInvoices);
router.post('/school-portal/fees/invoices/generate', requireSchoolAdmin, generateFeeInvoice);
router.get('/school-portal/fees/invoices/:id', requireSchoolAdmin, validateObjectId('id'), getFeeInvoice);
router.post('/school-portal/fees/invoices/:invoiceId/pay', requireSchoolAdmin, validateObjectId('invoiceId'), payFeeInvoice);
router.get('/school-portal/fees/payments', requireSchoolAdmin, listFeePayments);
router.get('/school-portal/fees/payments/:id', requireSchoolAdmin, validateObjectId('id'), getFeePayment);
router.post('/school-portal/fees/collect', requireSchoolAdmin, collectFeePayment);

// Finance Routes
router.get('/school-portal/finance/transactions', requireSchoolAdmin, listFinanceTransactions);
router.get('/school-portal/finance/summary', requireSchoolAdmin, getFinanceSummary);
router.post('/school-portal/finance/expenses', requireSchoolAdmin, recordExpense);

// Payroll & HR Endpoints
router.get('/school-portal/payroll/employees', requireSchoolAdmin, getEligibleEmployees);
router.get('/school-portal/payroll', requireSchoolAdmin, listPayrolls);
router.post('/school-portal/payroll', requireSchoolAdmin, createPayroll);
router.post('/school-portal/payroll/release', requireSchoolAdmin, releaseAllPayrolls);
router.get('/school-portal/payroll/:id', requireSchoolAdmin, getPayroll);
router.patch('/school-portal/payroll/:id/status', requireSchoolAdmin, updatePayrollStatus);
router.delete('/school-portal/payroll/:id', requireSchoolAdmin, deletePayroll);

// Staff Attendance Endpoints
router.get('/school-portal/attendance/staff', requireSchoolAdmin, getDailyAttendance);
router.get('/school-portal/attendance/staff/report', requireSchoolAdmin, getAttendanceReport);
router.post('/school-portal/attendance/staff', requireSchoolAdmin, saveDailyAttendance);
router.patch('/school-portal/attendance/staff/:employeeRefId', requireSchoolAdmin, updateSingleStatus);
router.post('/school-portal/attendance/staff/mark-all', requireSchoolAdmin, markAllStatus);
router.get('/school-portal/attendance/staff/monthly', requireSchoolAdmin, getMonthlySummary);

// Library Management Endpoints (accessible by School Admin & Librarian)
router.get('/school-portal/profile', requireLibrarian, getLibrarianProfile);
router.patch('/school-portal/profile', requireLibrarian, updateLibrarianProfile);
router.get('/school-portal/library/settings', requireLibrarian, getLibrarySettings);
router.patch('/school-portal/library/settings', requireLibrarian, updateLibrarySettings);
router.get('/school-portal/library/stats', requireLibrarian, getLibraryStats);
router.get('/school-portal/library/categories', requireLibrarian, getCategories);
router.post('/school-portal/library/categories', requireLibrarian, createCategory);
router.patch('/school-portal/library/categories/:id', requireLibrarian, validateObjectId(), updateCategory);
router.delete('/school-portal/library/categories/:id', requireLibrarian, validateObjectId(), deleteCategory);
router.get('/school-portal/library/authors', requireLibrarian, getAuthors);
router.get('/school-portal/library/publishers', requireLibrarian, getPublishers);
router.get('/school-portal/library/borrowers', requireLibrarian, getEligibleBorrowers);
router.get('/school-portal/library/notification-recipients', requireLibrarian, getNotificationRecipients);
router.post('/school-portal/library/notifications', requireLibrarian, sendLibraryNotification);

router.get('/school-portal/library/books', requireLibrarian, listBooks);
router.post('/school-portal/library/books', requireLibrarian, createBook);
router.get('/school-portal/library/books/:id', requireLibrarian, validateObjectId(), getBook);
router.patch('/school-portal/library/books/:id', requireLibrarian, validateObjectId(), updateBook);
router.delete('/school-portal/library/books/:id', requireLibrarian, validateObjectId(), deleteBook);

router.get('/school-portal/library/copies', requireLibrarian, listBookCopies);
router.post('/school-portal/library/copies', requireLibrarian, createBookCopy);
router.patch('/school-portal/library/copies/:id', requireLibrarian, validateObjectId(), updateBookCopy);
router.delete('/school-portal/library/copies/:id', requireLibrarian, validateObjectId(), deleteBookCopy);

router.get('/school-portal/library/issues', requireLibrarian, listIssues);
router.post('/school-portal/library/issues', requireLibrarian, issueBook);
router.post('/school-portal/library/issues/:id/return', requireLibrarian, validateObjectId(), returnBook);
router.post('/school-portal/library/issues/:id/renew', requireLibrarian, validateObjectId(), renewBook);
router.patch('/school-portal/library/issues/:id/fine', requireLibrarian, validateObjectId(), updateFineStatus);

router.get('/school-portal/library/reservations', requireLibrarian, listReservations);
router.post('/school-portal/library/reservations', requireLibrarian, createReservation);
router.patch('/school-portal/library/reservations/:id/approve', requireLibrarian, validateObjectId(), approveReservation);
router.patch('/school-portal/library/reservations/:id/reject', requireLibrarian, validateObjectId(), rejectReservation);
router.patch('/school-portal/library/reservations/:id/cancel', requireLibrarian, validateObjectId(), cancelReservation);
router.post('/school-portal/library/reservations/:id/fulfill', requireLibrarian, validateObjectId(), fulfillReservation);

router.get('/school-portal/library/transactions', requireLibrarian, listTransactions);
router.get('/school-portal/library/reports/:category', requireLibrarian, getReportData);

// Examination & Terms Endpoints
router.get('/school-portal/exams/stats', requirePrincipal, getExamStats);
router.get('/school-portal/exams', requirePrincipal, listExams);
router.post('/school-portal/exams', requirePrincipal, createExam);
router.get('/school-portal/exams/:id', requirePrincipal, getExam);
router.patch('/school-portal/exams/:id', requirePrincipal, updateExam);
router.delete('/school-portal/exams/:id', requirePrincipal, deleteExam);

// Exam Subjects
router.get('/school-portal/exams/:examId/subjects', requirePrincipal, listExamSubjects);
router.post('/school-portal/exams/:examId/subjects/seed', requirePrincipal, seedExamSubjects);
router.post('/school-portal/exams/:examId/subjects', requirePrincipal, addExamSubject);
router.patch('/school-portal/exams/:examId/subjects/:id', requirePrincipal, updateExamSubject);
router.delete('/school-portal/exams/:examId/subjects/:id', requirePrincipal, deleteExamSubject);

// Exam Schedule (Timetable)
router.get('/school-portal/exams/:examId/schedule', requirePrincipal, listSchedule);
router.post('/school-portal/exams/:examId/schedule', requirePrincipal, createScheduleEntry);
router.patch('/school-portal/exams/:examId/schedule/:id', requirePrincipal, updateScheduleEntry);
router.delete('/school-portal/exams/:examId/schedule/:id', requirePrincipal, deleteScheduleEntry);

// Marks Entry & Result Calculation
router.get('/school-portal/exams/:examId/marks', requirePrincipal, listMarksSheet);
router.post('/school-portal/exams/:examId/marks', requirePrincipal, saveMarks);
router.post('/school-portal/exams/:examId/results/calculate', requirePrincipal, calculateResults);
router.get('/school-portal/exams/:examId/results', requirePrincipal, listResults);
router.get('/school-portal/exams/:examId/results/:studentId', requirePrincipal, getStudentReportCard);

// ==========================================
// Hostel Management Endpoints (School Admin)
// ==========================================
router.get('/school-portal/hostel/lookups', requireSchoolAdmin, getHostelLookups);

// 1 · Hostels
router.get('/school-portal/hostel/hostels', requireSchoolAdmin, listHostels);
router.post('/school-portal/hostel/hostels', requireSchoolAdmin, createHostel);
router.get('/school-portal/hostel/hostels/:id', requireSchoolAdmin, getHostel);
router.patch('/school-portal/hostel/hostels/:id', requireSchoolAdmin, updateHostel);
router.delete('/school-portal/hostel/hostels/:id', requireSchoolAdmin, deleteHostel);

// 2 + 3 · Rooms & Beds
router.get('/school-portal/hostel/rooms', requireSchoolAdmin, listRooms);
router.post('/school-portal/hostel/rooms', requireSchoolAdmin, createRoom);
router.get('/school-portal/hostel/rooms/:id', requireSchoolAdmin, getRoom);
router.patch('/school-portal/hostel/rooms/:id', requireSchoolAdmin, updateRoom);
router.delete('/school-portal/hostel/rooms/:id', requireSchoolAdmin, deleteRoom);
router.get('/school-portal/hostel/beds', requireSchoolAdmin, listBeds);

// 4 · Wardens
router.get('/school-portal/hostel/wardens', requireSchoolAdmin, listWardens);
router.post('/school-portal/hostel/wardens', requireSchoolAdmin, createWarden);
router.get('/school-portal/hostel/wardens/:id', requireSchoolAdmin, getWarden);
router.patch('/school-portal/hostel/wardens/:id', requireSchoolAdmin, updateWarden);
router.delete('/school-portal/hostel/wardens/:id', requireSchoolAdmin, deleteWarden);
router.post('/school-portal/hostel/wardens/:id/hostel', requireSchoolAdmin, assignWardenToHostel);
router.delete('/school-portal/hostel/wardens/:id/hostel', requireSchoolAdmin, unassignWardenFromHostel);

// 5 · Student Allocations
router.get('/school-portal/hostel/allocations', requireSchoolAdmin, listAllocations);
router.post('/school-portal/hostel/allocations', requireSchoolAdmin, allocateStudent);
router.patch('/school-portal/hostel/allocations/:id', requireSchoolAdmin, updateAllocation);
router.delete('/school-portal/hostel/allocations/:id', requireSchoolAdmin, vacateAllocation);

// 6 · Yearly Hostel Fee
router.get('/school-portal/hostel/fees', requireSchoolAdmin, listHostelFees);
router.put('/school-portal/hostel/fees/:academicYearId', requireSchoolAdmin, setHostelFee);
router.delete('/school-portal/hostel/fees/:academicYearId', requireSchoolAdmin, deleteHostelFee);

// ==========================================
// Fee Management Endpoints (School Admin)
// ==========================================
router.get('/school-portal/fees/heads', requireSchoolAdmin, listFeeHeads);
router.post('/school-portal/fees/heads', requireSchoolAdmin, createFeeHead);
router.get('/school-portal/fees/structures', requireSchoolAdmin, listFeeStructures);
router.post('/school-portal/fees/structures', requireSchoolAdmin, createFeeStructure);
router.get('/school-portal/fees/assignments', requireSchoolAdmin, listStudentFeeAssignments);
router.post('/school-portal/fees/assignments', requireSchoolAdmin, createStudentFeeAssignment);
router.post('/school-portal/fees/collect', requireSchoolAdmin, collectFeePayment);
router.get('/school-portal/fees/payments', requireSchoolAdmin, listFeePayments);
router.get('/school-portal/finance/transactions', requireSchoolAdmin, listFinanceTransactions);
router.get('/school-portal/finance/summary', requireSchoolAdmin, getFinanceSummary);
router.post('/school-portal/finance/expenses', requireSchoolAdmin, recordExpense);

// ==========================================
// Transport Management Endpoints (School Admin)
// ==========================================
router.get('/school-portal/transport/lookups', requireSchoolAdmin, getTransportLookups);

// 1 · Vehicles
router.get('/school-portal/transport/vehicles', requireSchoolAdmin, listVehicles);
router.post('/school-portal/transport/vehicles', requireSchoolAdmin, createVehicle);
router.get('/school-portal/transport/vehicles/:id', requireSchoolAdmin, getVehicle);
router.patch('/school-portal/transport/vehicles/:id', requireSchoolAdmin, updateVehicle);
router.delete('/school-portal/transport/vehicles/:id', requireSchoolAdmin, deleteVehicle);

// 2 · Drivers
router.get('/school-portal/transport/drivers', requireSchoolAdmin, listDrivers);
router.post('/school-portal/transport/drivers', requireSchoolAdmin, uploadDriverFiles, convertDriverImages, createDriver);
router.get('/school-portal/transport/drivers/:id', requireSchoolAdmin, getDriver);
router.patch('/school-portal/transport/drivers/:id', requireSchoolAdmin, uploadDriverFiles, convertDriverImages, updateDriver);
router.post('/school-portal/transport/drivers/:id/vehicle', requireSchoolAdmin, assignVehicleToDriver);
router.delete('/school-portal/transport/drivers/:id/vehicle', requireSchoolAdmin, unassignVehicleFromDriver);
router.delete('/school-portal/transport/drivers/:id', requireSchoolAdmin, deleteDriver);

// 3 + 4 · Routes & Resources
router.get('/school-portal/transport/routes', requireSchoolAdmin, listRoutes);
router.post('/school-portal/transport/routes', requireSchoolAdmin, createRoute);
router.get('/school-portal/transport/routes/:id', requireSchoolAdmin, getRoute);
router.patch('/school-portal/transport/routes/:id', requireSchoolAdmin, updateRoute);
router.post('/school-portal/transport/routes/:id/assign', requireSchoolAdmin, assignRouteResources);
router.delete('/school-portal/transport/routes/:id/assign', requireSchoolAdmin, unassignRouteResources);
router.post('/school-portal/transport/routes/:id/unassign', requireSchoolAdmin, unassignRouteResources);
router.delete('/school-portal/transport/routes/:id', requireSchoolAdmin, deleteRoute);

// 3 · Route Stops
router.get('/school-portal/transport/routes/:routeId/stops', requireSchoolAdmin, listStops);
router.post('/school-portal/transport/routes/:routeId/stops', requireSchoolAdmin, createStop);
router.patch('/school-portal/transport/routes/:routeId/stops/reorder', requireSchoolAdmin, reorderStops);
router.patch('/school-portal/transport/stops/:id', requireSchoolAdmin, updateStop);
router.delete('/school-portal/transport/stops/:id', requireSchoolAdmin, deleteStop);

// 5 · Student Assignments
router.get('/school-portal/transport/assignments', requireSchoolAdmin, listAssignments);
router.post('/school-portal/transport/assignments', requireSchoolAdmin, assignStudent);
router.patch('/school-portal/transport/assignments/:id', requireSchoolAdmin, updateAssignment);
router.delete('/school-portal/transport/assignments/:id', requireSchoolAdmin, removeAssignment);

// 6 · Yearly Transport Fee
router.get('/school-portal/transport/fees', requireSchoolAdmin, listTransportFees);
router.put('/school-portal/transport/fees/:academicYearId', requireSchoolAdmin, setTransportFee);
router.delete('/school-portal/transport/fees/:academicYearId', requireSchoolAdmin, deleteTransportFee);

// 7 · Daily pickup / drop status — read-only here; it is recorded from the Transport Manager app
router.get('/school-portal/transport/daily', requireSchoolAdmin, getTransportOverview);
router.get('/school-portal/transport/daily/:routeId', requireSchoolAdmin, validateObjectId('routeId'), getTransportRouteRun);

// ==========================================
// HR Management Endpoints (accessible by School Admin & HR)
// ==========================================
router.get('/school-portal/hr/dashboard', requireHR, getHRDashboard);
router.get('/school-portal/hr/settings', requireHR, getHRSettings);
router.patch('/school-portal/hr/settings', requireHR, updateHRSettings);
router.get('/school-portal/hr/documents', requireHR, listHRDocuments);
router.post('/school-portal/hr/documents/upload', requireHR, uploadSchoolUserFiles, convertSchoolUserImages, uploadHRDocument);
router.patch('/school-portal/hr/documents/:id/verify', requireHR, verifyHRDocument);
router.delete('/school-portal/hr/documents/:id', requireHR, deleteHRDocument);
// Announcements
router.get('/school-portal/hr/announcements', requireHR, hrListAnnouncements);
router.post('/school-portal/hr/announcements', requireHR, hrCreateAnnouncement);
router.patch('/school-portal/hr/announcements/:id', requireHR, hrUpdateAnnouncement);
router.delete('/school-portal/hr/announcements/:id', requireHR, hrDeleteAnnouncement);

// HR Notifications
router.get('/school-portal/hr/notifications', requireHR, getHRNotifications);

// HR Profile & Credentials
router.get('/school-portal/hr/profile', requireHR, getHRProfile);
router.patch('/school-portal/hr/profile', requireHR, uploadSchoolUserFiles, convertSchoolUserImages, updateHRProfile);
router.patch('/school-portal/hr/password', requireHR, changeHRPassword);

// Employees
router.get('/school-portal/hr/employees', requireHR, hrListEmployees);
router.post('/school-portal/hr/employees', requireHR, uploadSchoolUserFiles, convertSchoolUserImages, hrCreateEmployee);
router.get('/school-portal/hr/employees/:id', requireHR, hrGetEmployee);
router.patch('/school-portal/hr/employees/:id', requireHR, uploadSchoolUserFiles, convertSchoolUserImages, hrUpdateEmployee);
router.patch('/school-portal/hr/employees/:id/status', requireHR, hrUpdateEmployeeStatus);
router.patch('/school-portal/hr/employees/:id/approve', requireHR, hrApproveEmployee);
router.patch('/school-portal/hr/employees/:id/reject', requireHR, hrRejectEmployee);
router.delete('/school-portal/hr/employees/:id', requireHR, hrDeleteEmployee);

// Departments
router.get('/school-portal/hr/departments', requireHR, hrListDepartments);
router.post('/school-portal/hr/departments', requireHR, hrCreateDepartment);
router.patch('/school-portal/hr/departments/:id', requireHR, hrUpdateDepartment);
router.delete('/school-portal/hr/departments/:id', requireHR, hrDeleteDepartment);

// Designations
router.get('/school-portal/hr/designations', requireHR, hrListDesignations);
router.post('/school-portal/hr/designations', requireHR, hrCreateDesignation);
router.patch('/school-portal/hr/designations/:id', requireHR, hrUpdateDesignation);
router.delete('/school-portal/hr/designations/:id', requireHR, hrDeleteDesignation);

// Attendance (Static routes BEFORE dynamic routes)
router.get('/school-portal/hr/attendance/monthly', requireHR, getHRMonthlyAttendance);
router.get('/school-portal/hr/attendance/report', requireHR, getHRAttendanceReport);
router.post('/school-portal/hr/attendance/mark-all', requireHR, markAllHRAttendance);
router.get('/school-portal/hr/attendance', requireHR, getHRAttendance);
router.post('/school-portal/hr/attendance', requireHR, saveHRAttendance);
router.patch('/school-portal/hr/attendance/:id', requireHR, updateSingleAttendance);

// Leave Management (Static routes BEFORE dynamic routes)
router.get('/school-portal/hr/leave/balance/:empId', requireHR, getLeaveBalance);
router.get('/school-portal/hr/leave', requireHR, listLeaveRequests);
router.post('/school-portal/hr/leave', requireHR, createLeaveRequest);
router.patch('/school-portal/hr/leave/:id/approve', requireHR, approveLeave);
router.patch('/school-portal/hr/leave/:id/reject', requireHR, rejectLeave);
router.patch('/school-portal/hr/leave/:id/cancel', requireHR, cancelLeave);

// Payroll (Static routes BEFORE dynamic routes)
router.get('/school-portal/hr/payroll/employees', requireHR, getHREligiblePayrollEmployees);
router.post('/school-portal/hr/payroll/release', requireHR, releaseAllHRPayrolls);
router.get('/school-portal/hr/payroll', requireHR, listHRPayrolls);
router.post('/school-portal/hr/payroll', requireHR, createHRPayroll);
router.get('/school-portal/hr/payroll/:id', requireHR, getHRPayroll);
router.get('/school-portal/hr/payroll/:id/slip', requireHR, getHRSalarySlip);
router.patch('/school-portal/hr/payroll/:id/status', requireHR, updateHRPayrollStatus);
router.delete('/school-portal/hr/payroll/:id', requireHR, deleteHRPayroll);

// Performance Reviews (Static routes BEFORE dynamic routes)
router.get('/school-portal/hr/performance', requireHR, listPerformanceReviews);
router.post('/school-portal/hr/performance', requireHR, createPerformanceReview);
router.get('/school-portal/hr/performance/:id', requireHR, getPerformanceReview);
router.patch('/school-portal/hr/performance/:id', requireHR, updatePerformanceReview);
router.delete('/school-portal/hr/performance/:id', requireHR, deletePerformanceReview);

// Reports
router.get('/school-portal/hr/reports/:category', requireHR, getHRReportData);

// ==========================================================================
// EVENTS — school-admin writes; principal + school-admin read (requirePrincipal
// already lets SCHOOLADMIN through). Static routes before :id.
// ==========================================================================
router.get('/school-portal/events/stats', requirePrincipal, getEventStats);
router.get('/school-portal/events', requirePrincipal, listEvents);
router.get('/school-portal/events/:id', requirePrincipal, getEvent);
router.post('/school-portal/events', requireSchoolAdmin, requirePermission('events.manage'), createEvent);
router.patch('/school-portal/events/:id', requireSchoolAdmin, requirePermission('events.manage'), updateEvent);
router.delete('/school-portal/events/:id', requireSchoolAdmin, requirePermission('events.manage'), deleteEvent);

// ==========================================================================
// HOMEWORK — school-admin writes; principal + school-admin read/monitor.
// ==========================================================================
router.get('/school-portal/homework/stats', requirePrincipal, getHomeworkStats);
router.get('/school-portal/homework/monitor', requirePrincipal, getHomeworkMonitor);
router.get('/school-portal/homework', requirePrincipal, listHomework);
router.get('/school-portal/homework/:id', requirePrincipal, getHomework);
router.post('/school-portal/homework', requireSchoolAdmin, requirePermission('homework.manage'), createHomework);
router.patch('/school-portal/homework/:id', requireSchoolAdmin, requirePermission('homework.manage'), updateHomework);
router.delete('/school-portal/homework/:id', requireSchoolAdmin, requirePermission('homework.manage'), deleteHomework);

// ==========================================================================
// MEETINGS — principal only. Static routes before :id.
// ==========================================================================
router.get('/school-portal/principal/meetings', requirePrincipal, listMeetings);
router.post('/school-portal/principal/meetings', requirePrincipal, createMeeting);
router.get('/school-portal/principal/meetings/:id', requirePrincipal, getMeeting);
router.patch('/school-portal/principal/meetings/:id/status', requirePrincipal, updateMeetingStatus);
router.patch('/school-portal/principal/meetings/:id', requirePrincipal, updateMeeting);
router.delete('/school-portal/principal/meetings/:id', requirePrincipal, deleteMeeting);

// ==========================================================================
// ADMISSIONS — school-admin. Static routes before :id.
// ==========================================================================
router.get('/school-portal/admissions/stats', requireSchoolAdmin, getAdmissionStats);
router.get('/school-portal/admissions', requireSchoolAdmin, listAdmissions);
router.post('/school-portal/admissions', requireSchoolAdmin, requirePermission('admissions.manage'), createAdmission);
router.get('/school-portal/admissions/:id', requireSchoolAdmin, getAdmission);
router.post('/school-portal/admissions/:id/approve', requireSchoolAdmin, requirePermission('admissions.approve'), approveAdmission);
router.patch('/school-portal/admissions/:id/status', requireSchoolAdmin, requirePermission('admissions.manage'), updateAdmissionStatus);
router.patch('/school-portal/admissions/:id', requireSchoolAdmin, requirePermission('admissions.manage'), updateAdmission);
router.delete('/school-portal/admissions/:id', requireSchoolAdmin, requirePermission('admissions.manage'), deleteAdmission);

// ==========================================================================
// INVENTORY / SCHOOL ASSETS — school-admin. Static routes before :id.
// ==========================================================================
router.get('/school-portal/inventory/stats', requireSchoolAdmin, getInventoryStats);
router.get('/school-portal/inventory/movements', requireSchoolAdmin, listStockMovements);
router.get('/school-portal/inventory/categories', requireSchoolAdmin, listAssetCategories);
router.post('/school-portal/inventory/categories', requireSchoolAdmin, createAssetCategory);
router.patch('/school-portal/inventory/categories/:id', requireSchoolAdmin, updateAssetCategory);
router.delete('/school-portal/inventory/categories/:id', requireSchoolAdmin, deleteAssetCategory);
router.get('/school-portal/inventory/assets', requireSchoolAdmin, listAssets);
router.post('/school-portal/inventory/assets', requireSchoolAdmin, requirePermission('inventory.manage'), createAsset);
router.get('/school-portal/inventory/assets/:id', requireSchoolAdmin, getAsset);
router.post('/school-portal/inventory/assets/:id/movement', requireSchoolAdmin, requirePermission('inventory.manage'), recordAssetMovement);
router.patch('/school-portal/inventory/assets/:id', requireSchoolAdmin, requirePermission('inventory.manage'), updateAsset);
router.delete('/school-portal/inventory/assets/:id', requireSchoolAdmin, requirePermission('inventory.manage'), deleteAsset);

// ==========================================================================
// COMMUNICATION HUB — school-admin.
// ==========================================================================
router.get('/school-portal/communication/announcements', requireSchoolAdmin, commListAnnouncements);
router.post('/school-portal/communication/announcements', requireSchoolAdmin, requirePermission('communication.manage'), commCreateAnnouncement);
router.post('/school-portal/communication/announcements/:id/publish', requireSchoolAdmin, requirePermission('communication.manage'), commPublishAnnouncement);
router.patch('/school-portal/communication/announcements/:id', requireSchoolAdmin, requirePermission('communication.manage'), commUpdateAnnouncement);
router.delete('/school-portal/communication/announcements/:id', requireSchoolAdmin, requirePermission('communication.manage'), commDeleteAnnouncement);
router.get('/school-portal/communication/broadcasts', requireSchoolAdmin, commListBroadcasts);
router.post('/school-portal/communication/broadcasts', requireSchoolAdmin, requirePermission('communication.manage'), commCreateBroadcast);
router.get('/school-portal/communication/threads', requireSchoolAdmin, commListThreads);
router.post('/school-portal/communication/threads/inbound', requireSchoolAdmin, commInboundMessage);
router.get('/school-portal/communication/threads/:key', requireSchoolAdmin, commGetThread);
router.post('/school-portal/communication/threads/:key/reply', requireSchoolAdmin, commReplyThread);

// ==========================================================================
// STUDENT ATTENDANCE — capture (school-admin) + monitoring (principal).
// Static routes before :param.
// ==========================================================================
router.get('/school-portal/attendance/students/monitor', requirePrincipal, getStudentAttendanceMonitor);
router.get('/school-portal/attendance/students/report', requirePrincipal, getStudentAttendanceReport);
router.get('/school-portal/attendance/students', requireSchoolAdmin, getStudentAttendanceDay);
router.post('/school-portal/attendance/students', requireSchoolAdmin, requirePermission('attendance.mark'), saveStudentAttendanceDay);
router.post('/school-portal/attendance/students/mark-all', requireSchoolAdmin, requirePermission('attendance.mark'), markAllStudentAttendance);
router.patch('/school-portal/attendance/students/:sectionId/:studentId', requireSchoolAdmin, requirePermission('attendance.mark'), markSingleStudentAttendance);

// ==========================================================================
// ROLES & PERMISSIONS — school-admin.
// ==========================================================================
router.get('/school-portal/permissions', requireSchoolAdmin, getPermissionCatalogue);
router.get('/school-portal/roles', requireSchoolAdmin, listRoles);
router.post('/school-portal/roles', requireSchoolAdmin, createRole);
router.get('/school-portal/roles/:id', requireSchoolAdmin, getRole);
router.patch('/school-portal/roles/:id', requireSchoolAdmin, updateRole);
router.delete('/school-portal/roles/:id', requireSchoolAdmin, deleteRole);
router.patch('/school-portal/users/:id/role', requireSchoolAdmin, assignUserRole);

// ==========================================================================
// AUDIT LOGS — school-admin (read).
// ==========================================================================
router.get('/school-portal/audit-logs', requireSchoolAdmin, listAuditLogs);

router.get('/subscriptions', requireSuperAdmin, listPlans);
router.post('/subscriptions', requireSuperAdmin, createPlan);
router.get('/subscriptions/:id', requireSuperAdmin, getPlan);
router.put('/subscriptions/:id', requireSuperAdmin, updatePlan);
router.post('/subscriptions/:id/archive', requireSuperAdmin, archivePlan);
router.delete('/subscriptions/:id', requireSuperAdmin, deletePlan);

// ==========================================================================
// SCHOOL SUBSCRIPTIONS (Razorpay recurring) — Super Admin. Static before :id.
// ==========================================================================
router.get('/school-subscriptions/stats', requireSuperAdmin, getSubscriptionStats);
router.get('/school-subscriptions', requireSuperAdmin, listSchoolSubscriptions);
router.post('/schools/:schoolId/subscription', requireSuperAdmin, createSchoolSubscription);
router.get('/school-subscriptions/:id', requireSuperAdmin, getSchoolSubscriptionById);
router.post('/school-subscriptions/:id/cancel', requireSuperAdmin, cancelSchoolSubscription);
router.post('/school-subscriptions/:id/change-plan', requireSuperAdmin, changeSchoolSubscriptionPlan);
router.post('/school-subscriptions/:id/override', requireSuperAdmin, overrideSchoolSubscription);
router.get('/school-subscriptions/:id/payments', requireSuperAdmin, listSubscriptionPayments);
router.get('/school-subscriptions/:id/invoices', requireSuperAdmin, listSubscriptionInvoices);
router.get('/school-subscriptions/:id/history', requireSuperAdmin, listSubscriptionHistory);

// SCHOOL SUBSCRIPTION — School Admin, always scoped to req.user's own school.
router.get('/school-portal/subscription/checkout-info', requireSchoolAdmin, getSubscriptionCheckoutInfo);
router.get('/school-portal/subscription', requireSchoolAdmin, getMySubscription);
router.get('/school-portal/subscription/entitlement', requireSchoolAdmin, getMyEntitlement);
router.post('/school-portal/subscription/checkout', requireSchoolAdmin, checkoutMySubscription);
router.post('/school-portal/subscription/change-plan', requireSchoolAdmin, changeMySubscriptionPlan);
router.post('/school-portal/subscription/cancel', requireSchoolAdmin, cancelMySubscription);
router.get('/school-portal/subscription/payments', requireSchoolAdmin, listMySubscriptionPayments);
router.get('/school-portal/subscription/invoices', requireSchoolAdmin, listMySubscriptionInvoices);
router.get('/school-portal/subscription/history', requireSchoolAdmin, listMySubscriptionHistory);
// Shared by every signed-in role; scope comes from the JWT, not the request.
router.post('/device-tokens', requirePlatformUser, registerDevice);
router.get('/notifications/inbox', requirePlatformUser, inboxNotifications);
router.get('/notifications', requireSuperAdmin, listNotifications);
router.post('/notifications', requireSuperAdmin, sendNotification);
router.get('/billings', requireSuperAdmin, listInvoices);
router.post('/billings', requireSuperAdmin, createInvoice);
router.get('/billings/gateway', requireSuperAdmin, getPaymentGateway);
router.get('/billings/:id', requireSuperAdmin, getInvoice);
router.post('/billings/:id/razorpay-order', requireSuperAdmin, createRazorpayOrder);
router.post('/billings/:id/razorpay-verify', requireSuperAdmin, verifyRazorpayPayment);
router.patch('/billings/:id/pay', requireSuperAdmin, markInvoicePaid);
router.patch('/billings/:id/refund', requireSuperAdmin, refundInvoice);
router.patch('/billings/:id/cancel', requireSuperAdmin, cancelInvoice);
router.get('/privacy-policy', getLegalDocuments);
router.put('/privacy-policy', requireSuperAdmin, updateLegalDocuments);
router.get('/app-config', getPlatformSettings);
router.put('/app-config', requireSuperAdmin, updatePlatformSettings);
router.put('/app-config/logo', requireSuperAdmin, uploadPlatformLogo, updatePlatformLogo);
router.delete('/app-config/logo', requireSuperAdmin, deletePlatformLogo);

// Mobile app: version-update push, and force logout of app roles (see appSession.service.js).
router.post('/app-config/notify-update', requireSuperAdmin, notifyAppUpdate);
router.get('/app-config/logout-notice', getLogoutNotice); // public — the app asks after a 401
router.get('/app-config/force-logout', requireSuperAdmin, superForceLogoutHistory);
router.post('/app-config/force-logout', requireSuperAdmin, superForceLogout);
router.get('/reports', requireSuperAdmin, getReportSummary);
router.get('/reports/schools', requireSuperAdmin, listSchoolReports);
router.get('/reports/subscriptions', requireSuperAdmin, listSubscriptionReports);
router.get('/reports/invoices', requireSuperAdmin, listInvoiceReports);
router.get('/reports/notifications', requireSuperAdmin, listNotificationReports);
router.get('/support/tickets', requireSuperAdmin, listTickets);
router.post('/support/tickets', requireSuperAdmin, createTicket);
router.get('/support/tickets/:id', requireSuperAdmin, getTicket);
router.post('/support/tickets/:id/replies', requireSuperAdmin, replyTicket);
router.patch('/support/tickets/:id/status', requireSuperAdmin, updateTicketStatus);
router.get('/support/school/:schoolId/tickets', requireSchoolAdmin, assertSchoolAccess, listSchoolTickets);
router.post('/support/school/:schoolId/tickets', requireSchoolAdmin, assertSchoolAccess, createSchoolTicket);
router.get('/support/school/:schoolId/tickets/:id', requireSchoolAdmin, assertSchoolAccess, getSchoolTicket);
router.post('/support/school/:schoolId/tickets/:id/replies', requireSchoolAdmin, assertSchoolAccess, replySchoolTicket);
// ===================== Teacher APK (see teacher.routes.js) =====================
router.use(teacherApkRoutes);

// ===================== Student APK (see student.routes.js) =====================
router.use(studentApkRoutes);

// ===================== Parent APK (see parent.routes.js) =====================
router.use(parentApkRoutes);

// ===================== Driver Portal (see driver.routes.js) =====================
router.use(driverRoutes);

// ============ Transport Manager app (see transportManager.routes.js) ============
router.use(transportManagerRoutes);

router.get('/', getServiceInfo);
router.use(notFound);

export default router;
