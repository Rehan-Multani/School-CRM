import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load routes
import authRoutes from '../services/auth-service/src/routes/authRoutes.js';
import platformRoutes from '../services/platform-service/src/routes/platformRoutes.js';
import { ensureUploadDirs, uploadsRoot } from '../services/platform-service/src/utils/upload.utils.js';
import { errorHandler as authErrorHandler } from '../services/auth-service/src/config/errorHandler.js';
import { errorHandler as platformErrorHandler } from '../services/platform-service/src/config/errorHandler.js';

dotenv.config();

const app = express();

// Ensure upload folders exist (in /tmp/uploads for Vercel)
ensureUploadDirs();

// Middlewares
const allowedOrigins = process.env.CORS_ORIGIN 
  ? process.env.CORS_ORIGIN.split(',').map(o => o.trim())
  : [];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    if (
      origin.startsWith('http://localhost:') || 
      origin.endsWith('.vercel.app') || 
      allowedOrigins.includes(origin)
    ) {
      return callback(null, true);
    }
    return callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));
app.use(morgan('combined'));
app.use(express.json({ limit: '5mb' }));

// Static route for uploads (ephemeral in Vercel /tmp)
app.use('/uploads', express.static(uploadsRoot));

// Mongoose Connection Cache
let cachedConnection = null;

async function connectDB() {
  if (cachedConnection && mongoose.connection.readyState === 1) {
    return cachedConnection;
  }
  
  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/school_crm_platform';
  mongoose.set('strictQuery', true);
  
  try {
    const conn = await mongoose.connect(mongoUri, {
      maxPoolSize: 10, // low for serverless environments
      serverSelectionTimeoutMS: 5000,
    });
    cachedConnection = conn;
    console.log('MongoDB connected successfully');
    return conn;
  } catch (error) {
    console.error('MongoDB connection error:', error.message);
    throw error;
  }
}

// Database Connection Middleware
app.use(async (req, res, next) => {
  try {
    await connectDB();
    next();
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Database connection failed',
      error: error.message,
    });
  }
});

// Health Checks (support both /health and /api/health for sub-path or root mount)
app.get(['/health', '/api/health'], (req, res) => {
  res.json({
    success: true,
    service: 'api-gateway-cpanel',
    status: 'HEALTHY',
    timestamp: new Date().toISOString(),
  });
});

app.get(['/ready', '/api/ready'], (req, res) => {
  res.json({
    success: true,
    status: 'READY',
    timestamp: new Date().toISOString(),
  });
});

// Routes (Support both /api/v1 and /v1 prefixes for cPanel sub-path /api or root)
app.use(['/api/v1/platform/auth', '/v1/platform/auth'], authRoutes);
app.use(['/api/v1/platform', '/v1/platform'], platformRoutes);

// Error handlers
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
});

app.use(authErrorHandler);
app.use(platformErrorHandler);

export default app;
